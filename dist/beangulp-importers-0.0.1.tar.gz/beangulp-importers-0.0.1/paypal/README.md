# Paypal importer

An importer for Paypal. Handles currency coversions and direct bank transfers.

## How to use
Please set your language to 'English' (currently the only supported language but I would be very happy with a PR) and enable the following csv entries:

- Transaction details - PayPal Balance
- Transaction details - Subject

## Contribution

This code is mainly for my own use and as such it is unlikely to fit all use cases yet. However, if you have an example that produces wrong output or an improvement, let me know. I think the main hurdle is having enough examples to test.
